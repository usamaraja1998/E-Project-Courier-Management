<?php
// Start the session
session_start();

// Connect to the database
$host = 'localhost';
$dbname = 'cms_db';
$user = 'root';
$password = '';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: ". $conn->connect_error);
}

// Get user input
$firstname = $_POST['firstname']?? '';
$lastname = $_POST['lastname']?? '';
$email = $_POST['email']?? '';
$password = $_POST['password']?? '';

// Check if the email already exists in the database
$query = "SELECT * FROM users WHERE email = '$email'";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    // Store the error message in a session variable
    $_SESSION['email_error'] = 'This email already exists. Please use a different email.';
    header('location: indexregister.php');
    exit;
}

// Hash the password using MD5 (NOT RECOMMENDED)
$password_hash = md5($password);

// Insert the user into the database
$sql = "INSERT INTO users (firstname, lastname, email, password) VALUES (?,?,?,?)";
$stmt = $conn->prepare($sql);
$stmt->execute([$firstname, $lastname, $email, $password_hash]);

header('Location: login.php');

$conn->close();
?>